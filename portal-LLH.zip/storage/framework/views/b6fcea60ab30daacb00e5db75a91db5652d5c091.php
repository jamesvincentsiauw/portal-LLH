<?php $__env->startSection('content'); ?>
    <h1 id="title-page" class="text-center">
        Laman Berita
    </h1>
    <div class="container text-center" style="padding:4% 0;">
        <?php if($news->count()>0): ?>
            <div class="row">
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 news-card-gap" onclick="window.location.href = '/news/detail/<?php echo e($item->id); ?>';">
                        <div class=" news-card">
                            <a>
                                <div class="news-img" style="background-image: url(<?php echo e(asset('img/img_1.jpg')); ?>)"></div>
                                <div class="news-info">
                                    <h4><?php echo e($item->title); ?></h4>
                                    <p class="news-date"><?php echo e($item->created_at); ?></p>
                                </div>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <h1 id="title-page" class="text-center font-weight-bold">
                Belum ada Berita Tersedia
            </h1>
        <?php endif; ?>
        <nav class="vertical-margin" aria-label="Page navigation example">
            <ul class="pagination justify-content-center">









                <?php echo e($news->links()); ?>

            </ul>
        </nav>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.home_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>