<?php $__env->startSection('content'); ?>
    <div class="container vertical-margin">
        <div class="text-center">
            <h1 id="title-page">
                <?php echo e($news->title); ?>

            </h1>
        </div>

        <div class="base-content">
            <p >By <strong class="blue-text"><?php echo e($news->author); ?></strong> - Bandung, <?php echo e($news->created_at->format('d-M-Y')); ?></p>
            <div class="text-center">
                <img src="<?php echo e(asset('img/image.jpg')); ?>" style="width:100%">
            </div>
            <p class="news-info">
                <?php echo e($news->body); ?>

            </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.home_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>