<?php $__env->startSection('content'); ?>
<h1 id="title-page" class="text-center">
    Hasil Pencarian
  </h1>

  <div class="container section">
    <div class="input-group">
      <input type="text" class="form-control" id="inlineFormInputGroupUsername" placeholder="Pencarian">
      <div class="input-group-append">
        <div class="input-group-text search-button" onclick="window.location.href = 'search_result.html';">
          <a class="fas fa-search"></a>
        </div>
      </div>
    </div>
  </div>
  </div>
  <div id="search-result" class="container table-responsive">
    <h2 class="justify-content-center"><strong class="text-danger"><?php echo e($documents->count()); ?></strong> results were found</h2>
    <table class="table table-striped text-center">
      <thead>
        <tr>
          <th scope="col">No</th>
          <th scope="col">Nomor SK</th>
          <th scope="col">Judul</th>
          <th scope="col" style="width:200px">Aksi</th>
        </tr>
      </thead>
      <tbody>
      <?php $i = 1 ?>
        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th scope="row"><?php echo e($i); ?></th>
            <td style="width:40px"><?php echo e($item->id); ?></td>
            <td><?php echo e($item->title); ?></td>
            <td>
              <div class="row">
                <div class="col">
                  <a href="<?php echo e($item->files); ?>" target="_blank" type="button"
                     class="btn btn-primary btn-sm">View</a>
                  <a href="<?php echo e($item->files); ?>" download="<?php echo e("FILE_".$item->title); ?>" type="button"
                     class="btn btn-primary btn-sm">Download</a>
                </div>
              </div>
            </td>
          </tr>
          <?php $i++ ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>

    <div style="height:40px;"></div>
    <nav aria-label="Page navigation example">
      <ul class="pagination justify-content-center">
        <li class="page-item disabled">
          <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
        </li>
        <li class="page-item"><a class="page-link" href="#">1</a></li>
        <li class="page-item"><a class="page-link" href="#">2</a></li>
        <li class="page-item"><a class="page-link" href="#">3</a></li>
        <li class="page-item">
          <a class="page-link" href="#">Next</a>
        </li>
      </ul>
    </nav>
  </div>
  

  <!-- Modal -->








  <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layout.home_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>