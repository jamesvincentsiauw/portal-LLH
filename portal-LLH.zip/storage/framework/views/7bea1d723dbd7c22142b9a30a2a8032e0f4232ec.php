<?php $__env->startSection('title'); ?>
    <h1 id="title-page" class="text-center">
        Penerimaan Permohonan Regulasi
    </h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1 id="title-page" class="text-center" style="color: transparent">
        Pengajuan Regulasi
    </h1>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success alert-block center-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong><?php echo e($message); ?></strong>
        </div>
    <?php endif; ?>

    <?php if($message = Session::get('alert')): ?>
        <div class="alert alert-danger alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong><?php echo e($message); ?></strong>
        </div>
    <?php endif; ?>
    <div class="card container justify-content-center">
        <form action="/submission/accept/<?php echo e($submission->id); ?>" method="POST" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="base-content" style="margin-top:50px;">
                <div class="form-group">
                    <label>ID Pengajuan</label>
                    <input class="form-control" name="submissionID" type="text" value="<?php echo e($submission->id); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Nama Pengaju</label>
                    <input class="form-control" name="submitterName" type="text" value="<?php echo e($submission->submitterName); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Email Pengaju</label>
                    <input class="form-control" name="ITBmail" type="text" value="<?php echo e($submission->submitterITBmail); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Judul Pengajuan</label>
                    <input class="form-control" name="title" type="text" value="<?php echo e($submission->title); ?>" disabled>
                </div>
                <div class="form-group">
                    <label>Upload File</label>
                    <a style="font-size: 5px; color: red" class="font-weight-bold alert">PLEASE UPLOAD .PDF FILES</a>
                    <div class=" upload-section ">
                        <input class="form-control-file" id='pict' type="file" accept="application/pdf" name="document" value="<?php echo e(old('document')); ?>" required/>
                    </div>
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-primary submit-button vertical-margin">
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>