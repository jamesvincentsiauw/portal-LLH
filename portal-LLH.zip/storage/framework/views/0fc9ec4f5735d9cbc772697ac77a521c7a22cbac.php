<?php $__env->startSection('title'); ?>
    <h1 id="title-page" class="text-center">
        Penyebaran Berita
    </h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1 id="title-page" class="text-center" style="color: transparent">
        Penyebaran Berita
    </h1>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success alert-block center-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong><?php echo e($message); ?></strong>
        </div>
    <?php endif; ?>

    <?php if($message = Session::get('alert')): ?>
        <div class="alert alert-danger alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong><?php echo e($message); ?></strong>
        </div>
    <?php endif; ?>
    <div class="card container justify-content-center">
        <form action="/admin/news/add" method="POST" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="base-content" style="margin-top:50px;">
                <div class="form-group">
                    <label>Judul Berita</label>
                    <input class="form-control" name="title" type="text" required>
                </div>
                <div class="form-group">
                    <label>Konten</label>
                    <input class="form-control" name="body" type="text" required>
                </div>
                <div class="form-group">
                    <label>Penulis</label>
                    <input class="form-control" name="author" type="text" value="Admin Lembaga Layanan Hukum ITB" disabled>
                </div>
                <div class="form-group">
                    <label>Upload Gambar Pendukung</label>
                    <div class=" upload-section ">
                        <input class="form-control-file" id='pict' type="file" name="image" value="<?php echo e(old('document')); ?>"/>
                    </div>
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-primary submit-button vertical-margin">
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>