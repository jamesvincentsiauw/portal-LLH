<?php $__env->startSection('content'); ?>
    <!-- News Carousel -->
    <div id="carouselExampleIndicators" class="carousel slide " data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item  active">
                <div class="carousel-bg" style="background-image: linear-gradient(
              rgba(0,0,20,.55),
              rgba(0,0,0,.65)),url('<?php echo e(asset('img/annex.jfif')); ?>');">
                    <img id="logo" src="<?php echo e(asset('img/logo-itb-1024px.png')); ?>">
                    <p id="home-title">
                        Lembaga Layanan Hukum
                        Institut Teknologi Bandung
                    </p>
                </div>
            </div>
            <div class="carousel-item">
                <div class="carousel-bg" style="background-image: linear-gradient(
              rgba(0,0,20,.55),
              rgba(0,0,0,.65)),url('<?php echo e(asset('img/image.jpg')); ?>');">
                </div>
            </div>
            <div class="carousel-item">
                <div class="carousel-bg" style="background-image: linear-gradient(
              rgba(0,0,20,.55),
              rgba(0,0,0,.65)),url('<?php echo e(asset('img/image.jpg')); ?>');">
                </div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <!-- Pencarian SK -->
    <div class="main-search align-items-center blue-bg">
        <div class="container">
            <div class="row">
                <div id="search-bar-title" class="col-md-3 my-auto">
                    Pencarian SK
                </div>
                <div class="col-md-9">
                    <form action="/search">
                        <div class="input-group">
                            <input type="text" name="keyword" class="form-control" id="inlineFormInputGroupUsername" placeholder="Pencarian" required>
                            <div class="input-group-append" style="background: white">
                                <button id="button-addon1"class="btn btn-link text-primary"><i
                                            class="fa fa-search"></i></button>
                            </div>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
    </div>




    <div class="container main-menu">
        <div class="row card-container">
            <div class="col-sm home-main-feature has-text-centered" data-aos="fade-up">
                <a href="/forms">
                    <div class="text-center">
                        <img class="main-feature-img" src="<?php echo e(asset('img/search.jpg')); ?>" alt="Image">
                    </div>
                    <div class="text-center">
                        <h2><strong>Pengajuan</strong></h2>
                        <h5>Fitur untuk pengajuan dokumen</h5>
                    </div>
                </a>
            </div>
            <div class="col-sm align-self-center home-main-feature has-text-centered" data-aos="fade-up">
                <a href="/tracks">
                    <div class="text-center">
                        <img class="main-feature-img" src="<?php echo e(asset('img/search.jpg')); ?>" alt="Image">
                    </div>
                    <div class="text-center">
                        <h2><strong>Pelacakan</strong></h2>
                        <h5>Lihat progress pengerjaan dari SK yang diajukan</h5>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="blue-bg">
        <div class="container ">
            <div class="row">
                <div class="col text-center">
                    <h1 id="statistic-1" class="gold-text"><?php echo e($sk); ?></h1>
                    <h4>Pengajuan SK</h4>
                </div>
                <div class="col text-center">
                    <h1 id="statistic-2" class="gold-text"><?php echo e($skpub); ?></h1>
                    <h4>SK Terbit</h4>
                </div>
                <div class="col text-center">
                    <h1 id="statistic-3" class="gold-text"><?php echo e($peraturan); ?></h1>
                    <h4>Pengajuan Peraturan</h4>
                </div>
                <div class="col text-center">
                    <h1 id="statistic-4" class="gold-text"><?php echo e($kerjasama); ?></h1>
                    <h4>Pengajuan Kerjasama</h4>
                </div>
            </div>
        </div>
    </div>

    <div class="container text-center" style="padding:4% 0;">
        <h1 id="title-page"><strong>Berita Terbaru</strong></h1>
        <div class="row">
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 news-card-gap" onclick="window.location.href = '/news/detail/<?php echo e($item->id); ?>';">
                <div class=" news-card" data-aos="fade-up">
                    <a>
                        <div class="news-img" style="background-image: url(<?php echo e($item->image); ?>)"></div>
                        <div class="news-info">
                            <h4><?php echo e($item->title); ?></h4>
                            <p class="news-date"> <?php echo e($item->created_at->format('d-M-Y')); ?></p>
                        </div>
                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button type="button" onclick="window.location.href = '/news';" class="btn btn-primary news-button vertical-margin">Lihat berita lainnya...</button>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.home_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>